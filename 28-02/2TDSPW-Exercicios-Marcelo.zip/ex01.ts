let cidade: string = "Diadema"

console.log(cidade)
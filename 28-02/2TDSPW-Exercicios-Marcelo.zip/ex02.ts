interface Carro{
    marca: string;
    ano: number;
}

let meuCarro: Carro = {
    marca: "Chevrolet",
    ano: 2023
}

console.log(meuCarro)

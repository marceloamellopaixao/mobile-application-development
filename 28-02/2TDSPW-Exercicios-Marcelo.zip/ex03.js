var animal = {
    emitirSom: function () {
        return "Miauuu";
    }
};
console.log(animal.emitirSom());

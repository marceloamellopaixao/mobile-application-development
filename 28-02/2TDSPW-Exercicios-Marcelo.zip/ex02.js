var meuCarro = {
    marca: "Chevrolet",
    ano: 2023
};
console.log(meuCarro);

var cidade = "Diadema";
console.log(cidade);
